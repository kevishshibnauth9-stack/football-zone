const matches=[
{league:'UEFA Nations League',time:'15:00',home:'Kazakhstan',away:'Faroe Islands',tag:'NATIONS',filter:'nations'},
{league:'UEFA Nations League',time:'19:45',home:'England',away:'Czechia',tag:'NATIONS',filter:'nations'},
{league:'UEFA Nations League',time:'19:45',home:'Croatia',away:'Spain',tag:'NATIONS',filter:'nations'},
{league:'UEFA Nations League',time:'19:45',home:'Belarus',away:'Finland',tag:'NATIONS',filter:'nations'},
{league:'EFL Trophy',time:'19:00',home:'Accrington ST',away:'Salford City',tag:'EFL',filter:'efl'},
{league:'EFL Trophy',time:'19:00',home:'Blackpool',away:'Crewe',tag:'EFL',filter:'efl'},
{league:'FA Cup',time:'19:45',home:'Atherton Collieries',away:'Trafford',tag:'FA CUP',filter:'fa'},
{league:'FA Cup',time:'19:45',home:'Scarborough Athletic',away:'Macclesfield',tag:'FA CUP',filter:'fa'}];
const list=document.getElementById('matchList');
function render(filter='all'){list.innerHTML=matches.filter(m=>filter==='all'||m.filter===filter).map(m=>`<article class="match"><div class="match-top"><span>${m.league}</span><span>${m.time}</span></div><div class="teams"><span>${m.home}</span><span class="vs">VS</span><span>${m.away}</span></div><span class="tag">${m.tag}</span></article>`).join('')}
render();document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{document.querySelectorAll('.filter').forEach(x=>x.classList.remove('active'));b.classList.add('active');render(b.dataset.filter)});
document.getElementById('menu').onclick=()=>document.querySelector('.nav').classList.toggle('open');document.getElementById('year').textContent=new Date().getFullYear();
