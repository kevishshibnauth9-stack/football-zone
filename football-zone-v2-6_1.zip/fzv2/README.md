# Football Zone V2
Mobile-first static Football Zone upgrade. Includes matchday dashboard, filters, daily picks, BTTS/Over 2.5/Correct Score/Half-Time markets, news notes, SEO metadata and responsive navigation.

## Deploy on Render
Static Site → connect the GitHub repository → Build Command blank → Publish Directory `.` → branch `main`.

## Data note
The displayed fixtures are a curated matchday snapshot. For fully automated live scores, standings and predictions, connect a football-data provider through a server-side API layer rather than exposing a secret token in browser JavaScript.
